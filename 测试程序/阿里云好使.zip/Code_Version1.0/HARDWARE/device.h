#ifndef _DEVICE_H_
#define _DEVICE_H_	 

void TempHumi_State(void);

#endif